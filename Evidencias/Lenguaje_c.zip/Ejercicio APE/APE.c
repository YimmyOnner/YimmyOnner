#include<stdio.h>
int main(){
    float not1, not2, not3, nc, nl, nf;
    float CANTIDAD_NOTAS = 3.0;
    printf("Ingrese su primera nota de la unidad \n");
    scanf("%f",&not1);
    getchar();
    printf("Ingrese su segunda nota de la unidad \n");
    scanf("%f",&not2);
    getchar();
    printf("Porfavor ingrese la nota de laboratorio \n");
    scanf("%f",&nl);
     getchar();
  
    nf=(60);
    nc=  (nf- nl * 0.3) / 0.7;

    not3= (CANTIDAD_NOTAS * nc - not1 - not2);

    printf("El valor de la tercera nota,"
        ", tomando en cuenta su primera nota %2f, la segunda %2f y la de laboratorio %2f, "
        ",es: %2f ", not1,not2,nl,not3);
}