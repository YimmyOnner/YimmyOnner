#include<stdio.h>
int main(){
    float ac, vo, v, t;
    printf("Ingrese el valor de la velocidad inicial (m): \n");
    scanf("%2f", &vo);
    getchar();
    printf("Ingrese el valor de la velocidad final (m): \n");
    scanf("%2f", &v);
    getchar();
    printf("Ingrese el valor del tiempo (s): \n");
    scanf("%2f", &t);
    getchar();

    ac=(v - vo) / t;
    
    printf("El valor de la aceleracion en metros sobre segundos al cuadrado es: %2f m/s^2 \n", ac);
    
}