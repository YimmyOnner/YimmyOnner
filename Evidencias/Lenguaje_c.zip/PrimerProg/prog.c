#include <stdio.h>
#include <stdlib.h>
int main(){
    /*
       char nombreCompleto[20];
       printf("Ingrese sus nombres completos: \n");
       scanf("%[^\n]s", nombreCompleto);
       getchar();
       printf("Sus nombres completos son: %s\n", nombreCompleto);
   */
    // Opcion 2
   /* char * nombres= malloc(20 * sizeof(char));
    printf("Ingrese sus nombres Completos: \n");
    scanf("%[^\n]s", nombres); 
    printf("Sus nombres completos son: %s\n", nombres);
    return 0;
    */
    char * nombreCompleto=" Yimmy Angulo";
    printf("Ingrese sus nombres completos: \n");
    scanf("%[^\n]s", nombreCompleto);
    getchar();
    printf("Sus nombres completos son: %s\n", nombreCompleto);

    return 0;
}