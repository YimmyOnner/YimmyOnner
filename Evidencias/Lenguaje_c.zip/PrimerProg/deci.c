#include<stdio.h>
#include<math.h>
int main(){
    double numero, decimal, entero;
    printf("Ingrese el numero que desee con decimales: \n");
    scanf("%lf", &numero);
    getchar();
    decimal = modf(numero, &entero);

    printf("Parte decimal es: %lf", decimal);
   printf("Parte decimal es: %lf", entero);
}