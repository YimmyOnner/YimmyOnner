#include<stdio.h>
#include<math.h>
int main(){
    float x1, y1, x2, y2, d;
    printf("Ingrese los puntos que desee(formato de introduccion de datos: x1,y1): \n");
    scanf("%f,%f", &x1,&y1);
    getchar();
    printf("Ingrese los puntos que desee(formato de introduccion de datos: x2 y y2): \n");
    scanf("%f,%f", &x2,&y2);
    getchar();
   
    d=sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
    
    printf("El valor de la distancia en los puntos datos (%f,%f) y (%f,%f) es: %f\n", x1,y1,x2,y2,d);
}