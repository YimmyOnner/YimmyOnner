#include<stdio.h>
int main(){
    float metros, kilom, cm, mm;
    printf("Ingrese los metros que desea convertir: \n");
    scanf("%2f", &metros);
    getchar();
    kilom= metros / 1000;
    cm= metros * 100;
    mm= metros * 1000;

    printf("El valor de metros que ingresi es: %2f \n", metros);
    printf("El valor de %2f m en kilometros es: %2f km \n",metros, kilom);
    printf("El valor de %2f m en centimetros es: %2f cm \n", metros, cm);
    printf("El valor de %2f m en milimetros es: %2f mm \n", metros, mm);
}