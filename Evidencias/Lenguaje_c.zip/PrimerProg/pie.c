#include<stdio.h>
int main(){
    float pies, yr, pg, cm, metros;
    printf("Ingrese valor de medida de su pie: \n");
    scanf("%2f",&pies);
    getchar();

    yr = pies /3;
    pg = pies * 12;
    cm = pg * 2.54;
    metros = cm / 100; 

    printf("El valor de su pie %2f ,tanto yr, pg, cm, m es: %2f yr, %2f pg, %2f cm y %2f m \n", pies,yr,pg,cm, metros);

    return 0;
} 