#include<stdio.h>
int main(){
    float numero, doble, triple;
    printf("Ingrese el numero que desee: \n");
    scanf("%f",&numero);
    getchar();

    doble= numero * 2;
    triple = numero * 3;

    printf("El doble y el triple del numero %f es: %f y %f\n", numero,doble, triple);
}