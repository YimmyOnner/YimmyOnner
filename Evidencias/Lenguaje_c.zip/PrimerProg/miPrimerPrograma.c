#include <stdio.h>
#define PI 3.1415

int main(){
     double numero,numero2,suma;    
     char nombresCompletos[]="";
    printf("Ingrese el valor del primer numero:\n ");
    scanf("%lf",&numero);
     printf("Ingrese el valor del primer numero:\n ");
    scanf("%lf",&numero2);
    getchar();
    suma=(numero + numero2);
    printf("La suma de los dos numeros es: %lf\n",suma);
}